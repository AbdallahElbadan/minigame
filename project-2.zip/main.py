map = ['sword_1' , 'staries down' , 'monsters_1' , 'sword_2' , 'trader' , 'magic stone' , 'stairs up or down' , 'monsters_2' , 'start' , 'sowrd_3' , 'gold' , 'stairs up' , 'monsters_3' , 'the boss' , 'prize']




player_index = 8
inventory = []
sword_1 = 1
sword_2 = 1
sword_3 = 1
trader = 1
magic_stone = 1
gold = 1
prize = 1
monsters_1 = 1
monsters_2 = 1
monsters_3 = 1
big_boss = 1


while (map[player_index]) != 14 :
 move = input("what do you want to do ")
 
 if move == 'right' :
    if player_index == 4 or player_index == 9 or player_index == 14 :
      print("you can't move this way")
    elif player_index == 2 and monsters_1 == 1 :
     print("you can't move this way")
    elif player_index == 12 and monsters_3 == 1 :
      print("you can't move this way")
    elif player_index == 13 and big_boss == 1 :
      print("you can't move this way")
    else :
      player_index = player_index + 1
      print(map[player_index])
 elif move == 'left':
      if player_index == 0 or player_index == 5 or player_index == 10 :
        print("you can't move this way")
      elif player_index == 7 and monsters_2 == 1 :
       print("you can't move this way")
      else :
       player_index = player_index - 1
       print(map[player_index])
 elif move == 'up' :
     if player_index == 6 or player_index == 11 :
      player_index = player_index - 5
      print(map[player_index])
     else :
       print("you can't go this way")
 elif move == 'down' :
     if player_index == 1 or player_index == 6 :
      player_index = player_index + 5
      print (map[player_index])
     else :
       print("you can't go this way")
 elif move == 'grab' and len(inventory) < 3 :
     if player_index == 0 and sword_1 == 1:
       print("grab sword")
       inventory.append('sword')
       sword_1 = 0
     elif player_index == 3 and  sword_2 == 1:
       print("grab the sword")
       inventory.append("sword")
       sword_2 = 0
     elif player_index == 9 and sword_3 == 1 :
       print("grab sword")
       sword_3 = 0
       inventory.append("sword")
     elif player_index == 4 and trader == 1 and 'gold' in inventory :
       
       inventory.remove('gold')
       print("grab big boss sword")
       inventory.append('big sword')
       trader = 0
     elif player_index == 5 and magic_stone == 1 :
       print("grab magic stone")
       inventory.append("magic stone")
       magic_stone = 0
     elif player_index == 10 and gold == 1 :
       print("grab the gold")
       inventory.append('gold')
       gold = 0
     elif player_index == 15 and prize == 1 :
       print("grap the prize")
       prize = 0
     else :
       print("you can't grab it")
 elif move == 'inventory' :
   print(inventory)    
 elif move == 'fight' :
   if player_index == 2 and 'sword' in inventory and monsters_1 == 1 :
     print('monsters has been defated but you broke your sword')
     monsters_1 = 0
     inventory.remove('sword')
   elif player_index == 7 and 'sword' in inventory and monsters_2 == 1 :
     print("the monsters has benn defated but you broke your sword")
     inventory.remove('sword')
     monsters_2 = 0
   elif player_index == 12 and 'sword' in inventory and monsters_3 == 1 :
     print("you has been defated the monsters but you broke your sword")
     inventory.remove('sword') 
     monsters_3 = 0
   elif player_index == 13 and 'magic stone' in inventory and 'big sword' in inventory and big_boss == 1 :
     print("you have been defated the big boss")
     big_boss = 0
   else :
     print("you can't defeat them")
  



  
       
 
 
 
 
 
    






















 
 

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 if move == 'end' :
   break